package com.example.soilcalc

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.pow

class MainActivity : ComponentActivity() {
    private val vm: SoilCalcViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SoilCalcApp(vm)
                }
            }
        }
    }
}

enum class CalcMode {
    DUKER,
    REPAIR
}

data class GranInputRow(
    val dCm: String = "",
    val pFiner: String = ""
)

data class SegmentInputRow(
    val fi: String = "",
    val bi: String = ""
)

class SoilCalcViewModel : ViewModel() {
    var mode by mutableStateOf(CalcMode.DUKER)

    var q50 by mutableStateOf("")
    var fLive by mutableStateOf("")
    var bLive by mutableStateOf("")
    var bTrench by mutableStateOf("")

    var waterTemp by mutableStateOf("10")
    var rho by mutableStateOf("1000")
    var rhoS by mutableStateOf("2650")

    var vRazr by mutableStateOf("")
    var vTrench by mutableStateOf("")
    var kP by mutableStateOf("")
    var kZap by mutableStateOf("1.0")

    var vPipe by mutableStateOf("")
    var vT by mutableStateOf("")
    var vMesh by mutableStateOf("")

    var granRows = androidx.compose.runtime.mutableStateListOf(
        GranInputRow(),
        GranInputRow()
    )

    var segmentRows = androidx.compose.runtime.mutableStateListOf<SegmentInputRow>()

    private val _resultText = MutableStateFlow(defaultResult())
    val resultText: StateFlow<String> = _resultText.asStateFlow()

    fun updateGranRow(index: Int, row: GranInputRow) {
        granRows[index] = row
    }

    fun addGranRow() {
        granRows.add(GranInputRow())
    }

    fun removeGranRow(index: Int) {
        if (granRows.size > 2) {
            granRows.removeAt(index)
        }
    }

    fun addSegmentRow() {
        segmentRows.add(SegmentInputRow())
    }

    fun updateSegmentRow(index: Int, row: SegmentInputRow) {
        segmentRows[index] = row
    }

    fun removeSegmentRow(index: Int) {
        segmentRows.removeAt(index)
    }

    fun clearAll() {
        mode = CalcMode.DUKER
        q50 = ""
        fLive = ""
        bLive = ""
        bTrench = ""
        waterTemp = "10"
        rho = "1000"
        rhoS = "2650"
        vRazr = ""
        vTrench = ""
        kP = ""
        kZap = "1.0"
        vPipe = ""
        vT = ""
        vMesh = ""
        granRows.clear()
        granRows.add(GranInputRow())
        granRows.add(GranInputRow())
        segmentRows.clear()
        _resultText.value = defaultResult()
    }

    fun calculate(): Result<String> = runCatching {
        val curve = parseCurve()
        val segments = parseSegments()

        val q50Value = parseNumber(q50, "Q50%")
        val fLiveValue = parseNumber(fLive, "Fж.сеч")
        val bLiveValue = parseNumber(bLive, "Bж.сеч")
        val bTrenchValue = parseNumber(bTrench, "Bт")
        val tempValue = parseNumber(waterTemp, "T воды")
        val rhoValue = parseNumber(rho, "ρ воды")
        val rhoSValue = parseNumber(rhoS, "ρs")
        val vRazrValue = parseNumber(vRazr, "Vразр")
        val vTrenchValue = parseNumber(vTrench, "Vтранш")
        val kPValue = parseNumber(kP, "kр")
        val kZapValue = parseNumber(kZap, "kзап")

        if (kZapValue <= 0.0) {
            error("kзап должно быть > 0")
        }

        val vCp = calcVCp(q50Value, fLiveValue)
        val hCp = calcHCp(fLiveValue, bLiveValue)
        val omegaKr = calcOmegaKr(hCp, vCp, bTrenchValue)
        val dCrit = calcDCritCm(omegaKr, rhoValue, rhoSValue, tempValue)
        val kUnos = calcKUnos(dCrit, curve)
        val vUnos = calcVUnos(kUnos, vRazrValue)

        val sb = StringBuilder()
        sb.appendLine("=== Расчёт уноса грунта течением ===")
        sb.appendLine()
        sb.appendLine("Режим: ${if (mode == CalcMode.DUKER) "Укладка дюкера" else "Ремонт трубопровода"}")
        sb.appendLine()
        sb.appendLine("(1) vср = Q50 / Fж.сеч = ${fmt(vCp)} м/с")
        sb.appendLine("(3) hср = Fж.сеч / Bж.сеч = ${fmt(hCp)} м")
        sb.appendLine("(2) ωкр = hср × vср / Bт = ${fmt(omegaKr)} м/с")
        sb.appendLine("(4) dкр = ${fmt(dCrit)} см")
        sb.appendLine("kунос = P(d < dкр) = ${fmt(kUnos * 100.0)} %")
        sb.appendLine("(5) Vунос = kунос × Vразр = ${fmt(vUnos)} м³")
        sb.appendLine()

        val vDop = if (mode == CalcMode.DUKER) {
            val vPipeValue = parseNumber(vPipe, "Vтруб")
            val vTValue = parseNumber(vT, "VT")
            calcVDop1(vUnos, vTrenchValue, kPValue, vPipeValue, vTValue, kZapValue).also {
                sb.appendLine("(9) Vдоп(1) = (Vун + Vтранш × (1 - kр) - Vтруб - VT) × kзап = ${fmt(it)} м³")
                sb.appendLine("Если результат < 0, дополнительный привозной грунт не требуется.")
            }
        } else {
            val vMeshValue = parseNumber(vMesh, "Vмеш")
            calcVDop2(vUnos, vTrenchValue, kPValue, vMeshValue, kZapValue).also {
                sb.appendLine("(10) Vдоп(2) = (Vун + Vтранш × (1 - kр) - Vмеш) × kзап = ${fmt(it)} м³")
                sb.appendLine("Если результат < 0, дополнительный привозной грунт не требуется.")
                if (segments.isNotEmpty()) {
                    val deltas = segments.map { calcDeltaI(it.first, it.second) }
                    val zeta = calcZeta(q50Value, deltas)
                    val qis = deltas.map { calcQi(zeta, it) }

                    sb.appendLine()
                    sb.appendLine("Формулы (6–8) для отсеков:")
                    sb.appendLine("Σδi = ${fmt(deltas.sum())}")
                    sb.appendLine("ζ = Q50 / Σδi = ${fmt(zeta)}")
                    qis.forEachIndexed { index, qi ->
                        val s = segments[index]
                        sb.appendLine("Отсек ${index + 1}: Fi=${fmt(s.first)}, bi=${fmt(s.second)}, δi=${fmt(deltas[index])}, Qi=${fmt(qi)} м³/с")
                    }
                }
            }
        }

        sb.appendLine()
        sb.appendLine("Итог:")
        if (vDop < 0.0) {
            sb.appendLine("• Дополнительный привозной грунт не требуется.")
        } else {
            sb.appendLine("• Требуется дополнительный привозной грунт.")
        }

        val result = sb.toString().trim()
        _resultText.value = result
        result
    }

    private fun parseCurve(): List<Pair<Double, Double>> {
        val rows = granRows.mapIndexedNotNull { index, row ->
            val d = row.dCm.trim()
            val p = row.pFiner.trim()
            when {
                d.isEmpty() && p.isEmpty() -> null
                d.isEmpty() || p.isEmpty() -> error("Строка грансостава ${index + 1} заполнена не полностью")
                else -> {
                    val dValue = parseNumber(d, "d в строке ${index + 1}")
                    val pValue = parseNumber(p, "% мельче в строке ${index + 1}")
                    if (dValue < 0.0) error("d не может быть < 0")
                    if (pValue !in 0.0..100.0) error("% мельче должен быть в диапазоне 0..100")
                    dValue to pValue
                }
            }
        }
        if (rows.size < 2) {
            error("Нужно минимум 2 точки грансостава")
        }
        return rows.sortedBy { it.first }
    }

    private fun parseSegments(): List<Pair<Double, Double>> {
        return segmentRows.mapIndexedNotNull { index, row ->
            val fiText = row.fi.trim()
            val biText = row.bi.trim()
            when {
                fiText.isEmpty() && biText.isEmpty() -> null
                fiText.isEmpty() || biText.isEmpty() -> error("Строка отсеков ${index + 1} заполнена не полностью")
                else -> {
                    val fiValue = parseNumber(fiText, "Fi в строке ${index + 1}")
                    val biValue = parseNumber(biText, "bi в строке ${index + 1}")
                    if (fiValue < 0.0) error("Fi не может быть < 0")
                    if (biValue <= 0.0) error("bi должно быть > 0")
                    fiValue to biValue
                }
            }
        }
    }

    companion object {
        private fun defaultResult(): String = "Здесь появится результат расчёта."
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoilCalcApp(externalVm: SoilCalcViewModel? = null) {
    val vm: SoilCalcViewModel = externalVm ?: viewModel()
    val context = LocalContext.current
    val resultText by vm.resultText.collectAsState()
    var selectedTab by remember { mutableStateOf(0) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val createTxtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(resultText)
            }
            Toast.makeText(context, "Результат сохранён", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            Toast.makeText(context, e.message ?: "Ошибка сохранения", Toast.LENGTH_LONG).show()
        }
    }

    val tabs = listOf("Данные", "Грансостав", "Отсеки", "Результат")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Унос грунта") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            ScrollableTabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    val enabled = vm.mode == CalcMode.REPAIR || index != 2
                    Tab(
                        selected = selectedTab == index,
                        onClick = { if (enabled) selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                            )
                        }
                    )
                }
            }

            when (selectedTab) {
                0 -> InputScreen(
                    vm = vm,
                    onCalculate = {
                        vm.calculate()
                            .onSuccess { selectedTab = 3 }
                            .onFailure { errorMessage = it.message ?: "Ошибка расчёта" }
                    },
                    onClearAll = { vm.clearAll() }
                )

                1 -> GranScreen(vm = vm)
                2 -> SegmentScreen(vm = vm)
                3 -> ResultScreen(
                    resultText = resultText,
                    onCalculate = {
                        vm.calculate()
                            .onFailure { errorMessage = it.message ?: "Ошибка расчёта" }
                    },
                    onSaveTxt = { createTxtLauncher.launch("soilcalc_result.txt") }
                )
            }
        }
    }

    if (errorMessage != null) {
        AlertDialog(
            onDismissRequest = { errorMessage = null },
            confirmButton = {
                TextButton(onClick = { errorMessage = null }) {
                    Text("ОК")
                }
            },
            title = { Text("Ошибка") },
            text = { Text(errorMessage ?: "") }
        )
    }
}

@Composable
fun InputScreen(
    vm: SoilCalcViewModel,
    onCalculate: () -> Unit,
    onClearAll: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionCard(title = "Режим расчёта") {
                ModeButtons(mode = vm.mode, onChange = { vm.mode = it })
            }
        }

        item {
            SectionCard(title = "Гидроморфометрия") {
                DecimalField("Q50% (м³/с)", vm.q50) { vm.q50 = it }
                DecimalField("Fж.сеч (м²)", vm.fLive) { vm.fLive = it }
                DecimalField("Bж.сеч (м)", vm.bLive) { vm.bLive = it }
                DecimalField("Bт (ширина раскрытия траншеи, м)", vm.bTrench) { vm.bTrench = it }
            }
        }

        item {
            SectionCard(title = "Физические параметры") {
                DecimalField("T воды (°C)", vm.waterTemp) { vm.waterTemp = it }
                DecimalField("ρ воды (кг/м³)", vm.rho) { vm.rho = it }
                DecimalField("ρs частиц грунта (кг/м³)", vm.rhoS) { vm.rhoS = it }
            }
        }

        item {
            SectionCard(title = "Объёмы и коэффициенты") {
                DecimalField("Vразр (м³)", vm.vRazr) { vm.vRazr = it }
                DecimalField("Vтранш (м³)", vm.vTrench) { vm.vTrench = it }
                DecimalField("kр", vm.kP) { vm.kP = it }
                DecimalField("kзап", vm.kZap) { vm.kZap = it }
                if (vm.mode == CalcMode.DUKER) {
                    DecimalField("Vтруб (м³)", vm.vPipe) { vm.vPipe = it }
                    DecimalField("VT (м³)", vm.vT) { vm.vT = it }
                } else {
                    DecimalField("Vмеш (м³)", vm.vMesh) { vm.vMesh = it }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            ) {
                Text(
                    text = "Сначала заполните исходные данные, затем внесите грансостав. Для режима ремонта можно добавить отсеки на отдельной вкладке.",
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onCalculate, modifier = Modifier.weight(1f)) {
                    Text("Рассчитать")
                }
                TextButton(onClick = onClearAll, modifier = Modifier.weight(1f)) {
                    Text("Очистить всё")
                }
            }
        }
    }
}

@Composable
fun GranScreen(vm: SoilCalcViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionCard(title = "Грансостав") {
                Text(
                    text = "Введите минимум 2 точки. Формат: d, см и % мельче (0..100). Пустые строки игнорируются.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { vm.addGranRow() }) {
                    Text("Добавить строку")
                }
            }
        }

        itemsIndexed(vm.granRows) { index, row ->
            ElevatedCard {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Точка ${index + 1}", fontWeight = FontWeight.SemiBold)
                    DecimalField("d, см", row.dCm) {
                        vm.updateGranRow(index, row.copy(dCm = it))
                    }
                    DecimalField("% мельче", row.pFiner) {
                        vm.updateGranRow(index, row.copy(pFiner = it))
                    }
                    if (vm.granRows.size > 2) {
                        TextButton(onClick = { vm.removeGranRow(index) }) {
                            Text("Удалить")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SegmentScreen(vm: SoilCalcViewModel) {
    if (vm.mode != CalcMode.REPAIR) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = "Вкладка доступна только в режиме «Ремонт трубопровода».",
                modifier = Modifier.padding(24.dp)
            )
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionCard(title = "Отсеки") {
                Text(
                    text = "Отсеки используются для расчёта δi, ζ и Qi по формулам (6–8). Пустые строки игнорируются.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { vm.addSegmentRow() }) {
                    Text("Добавить отсек")
                }
            }
        }

        itemsIndexed(vm.segmentRows) { index, row ->
            ElevatedCard {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Отсек ${index + 1}", fontWeight = FontWeight.SemiBold)
                    DecimalField("Fi, м²", row.fi) {
                        vm.updateSegmentRow(index, row.copy(fi = it))
                    }
                    DecimalField("bi, м", row.bi) {
                        vm.updateSegmentRow(index, row.copy(bi = it))
                    }
                    TextButton(onClick = { vm.removeSegmentRow(index) }) {
                        Text("Удалить")
                    }
                }
            }
        }
    }
}

@Composable
fun ResultScreen(
    resultText: String,
    onCalculate: () -> Unit,
    onSaveTxt: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onCalculate, modifier = Modifier.weight(1f)) {
                    Text("Пересчитать")
                }
                Button(onClick = onSaveTxt, modifier = Modifier.weight(1f)) {
                    Text("Сохранить TXT")
                }
            }
        }

        item {
            ElevatedCard {
                Text(
                    text = resultText,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ModeButtons(mode: CalcMode, onChange: (CalcMode) -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterButton(
            text = "Укладка дюкера",
            selected = mode == CalcMode.DUKER,
            onClick = { onChange(CalcMode.DUKER) }
        )
        FilterButton(
            text = "Ремонт трубопровода",
            selected = mode == CalcMode.REPAIR,
            onClick = { onChange(CalcMode.REPAIR) }
        )
    }
}

@Composable
fun FilterButton(text: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, shape = RoundedCornerShape(20.dp)) {
            Text(text = text)
        }
    } else {
        OutlinedButton(onClick = onClick, shape = RoundedCornerShape(20.dp)) {
            Text(text = text)
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                HorizontalDivider()
                content()
            }
        )
    }
}

@Composable
fun DecimalField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

private fun parseNumber(raw: String, fieldName: String): Double {
    val normalized = raw.replace(',', '.').trim()
    if (normalized.isEmpty()) {
        error("Поле «$fieldName» не заполнено")
    }
    return normalized.toDoubleOrNull() ?: error("Поле «$fieldName» заполнено некорректно")
}

private fun calcVCp(q50: Double, fLive: Double): Double {
    require(fLive > 0.0) { "Fж.сеч должно быть > 0" }
    return q50 / fLive
}

private fun calcHCp(fLive: Double, bLive: Double): Double {
    require(bLive > 0.0) { "Bж.сеч должно быть > 0" }
    return fLive / bLive
}

private fun calcOmegaKr(hCp: Double, vCp: Double, bTrench: Double): Double {
    require(bTrench > 0.0) { "Bт должно быть > 0" }
    return (hCp * vCp) / bTrench
}

private fun calcDCritCm(omegaKr: Double, rho: Double, rhoS: Double, tempC: Double): Double {
    require(rhoS > rho) { "ρs должно быть > ρ" }
    return (omegaKr * rho) / ((rhoS - rho) * 67.7) - (0.52 * (tempC / 26.0 - 1.0)) / 67.7
}

private fun interpPercentFiner(dCm: Double, curve: List<Pair<Double, Double>>): Double {
    require(curve.isNotEmpty()) { "Грансостав пуст" }

    if (dCm <= curve.first().first) return curve.first().second
    if (dCm >= curve.last().first) return curve.last().second

    for (i in 1 until curve.size) {
        if (dCm <= curve[i].first) {
            val (x0, y0) = curve[i - 1]
            val (x1, y1) = curve[i]
            val t = if ((x1 - x0) != 0.0) (dCm - x0) / (x1 - x0) else 0.0
            return y0 + t * (y1 - y0)
        }
    }
    return curve.last().second
}

private fun calcKUnos(dCritCm: Double, curve: List<Pair<Double, Double>>): Double {
    val p = interpPercentFiner(dCritCm, curve).coerceIn(0.0, 100.0)
    return p / 100.0
}

private fun calcVUnos(kUnos: Double, vRazr: Double): Double = kUnos * vRazr

private fun calcDeltaI(fi: Double, bi: Double): Double {
    require(bi > 0.0) { "bi должно быть > 0" }
    require(fi >= 0.0) { "Fi не может быть < 0" }
    return ((fi / bi).pow(5.0 / 3.0)) * bi
}

private fun calcZeta(q50: Double, deltas: List<Double>): Double {
    val sum = deltas.sum()
    require(sum > 0.0) { "Σδi должно быть > 0" }
    return q50 / sum
}

private fun calcQi(zeta: Double, delta: Double): Double = zeta * delta

private fun calcVDop1(vUnos: Double, vTrenchGeom: Double, kP: Double, vPipe: Double, vT: Double, kZap: Double): Double {
    return (vUnos + vTrenchGeom * (1.0 - kP) - vPipe - vT) * kZap
}

private fun calcVDop2(vUnos: Double, vTrenchGeom: Double, kP: Double, vMesh: Double, kZap: Double): Double {
    return (vUnos + vTrenchGeom * (1.0 - kP) - vMesh) * kZap
}

private fun fmt(value: Double): String {
    val symbols = DecimalFormatSymbols(Locale("ru", "RU")).apply {
        decimalSeparator = ','
    }
    val df = DecimalFormat("0.######", symbols)
    return df.format(value)
}
